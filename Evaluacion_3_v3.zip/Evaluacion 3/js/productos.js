/**
 * INTEGRANTE 2: CARGA Y VISUALIZACIÓN DE PRODUCTOS
 * Funcionalidad: Cargar productos dinámicamente desde JavaScript
 * Descripción: Renderiza la grilla de productos con imágenes placeholder y info
 */

function agregarProductosImportados(items) {
  items.forEach(item => {
    if (!productos.some(p => String(p.id) === String(item.id))) {
      productos.push(item);
    }
  });
}

function normalizarTexto(texto) {
  return texto
    ? texto
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
    : '';
}

function mostrarSpinnerProductos() {
  const productosGrid = document.getElementById('productosGrid');
  if (!productosGrid) return;

  productosGrid.classList.add('loading');
  if (!document.getElementById('productosSpinner')) {
    const spinner = document.createElement('div');
    spinner.id = 'productosSpinner';
    spinner.className = 'productos-spinner';
    spinner.innerHTML = `
      <div class="loader"></div>
      <p>Cargando productos...</p>
    `;
    productosGrid.appendChild(spinner);
  }
}

function ocultarSpinnerProductos() {
  const productosGrid = document.getElementById('productosGrid');
  if (!productosGrid) return;
  productosGrid.classList.remove('loading');
  const spinner = document.getElementById('productosSpinner');
  if (spinner) spinner.remove();
}

function limpiarMensajeCargaProductos() {
  const productosGrid = document.getElementById('productosGrid');
  if (!productosGrid) return;
  const errorMsg = productosGrid.querySelector('.productos-error');
  if (errorMsg) errorMsg.remove();
}

function mostrarErrorCargaProductos(mensaje) {
  const productosGrid = document.getElementById('productosGrid');
  if (!productosGrid) return;
  limpiarMensajeCargaProductos();

  const errorDiv = document.createElement('div');
  errorDiv.className = 'productos-error';
  errorDiv.textContent = mensaje;
  productosGrid.appendChild(errorDiv);
}

function renderizarProductos(lista) {
  const productosGrid = document.getElementById('productosGrid');
  if (!productosGrid) return;
  productosGrid.innerHTML = '';
  lista.forEach(producto => {
    const card = crearCardProducto(producto);
    productosGrid.appendChild(card);
  });
}

function cargarProductos() {
  renderizarProductos(productos);
  cargarProductosImportados();
}

async function cargarProductosImportados() {
  const productosGrid = document.getElementById('productosGrid');
  const endpoint = 'https://dummyjson.com/products/category/tops?limit=20';
  
  // Solo mostrar spinner si estamos en la página de productos
  if (productosGrid) {
    limpiarMensajeCargaProductos();
    mostrarSpinnerProductos();
  }

  try {
    const response = await fetch(endpoint);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const datos = await response.json();

    if (Array.isArray(datos.products) && datos.products.length > 0) {
      const productosImportados = datos.products.map(item => {
        return {
          id: item.id,
          nombre: item.title,
          categoria: 'casual',
          genero: 'unisex',
          talla: 'M',
          sizes: ['XS', 'S', 'M', 'L', 'XL'],
          precio: Math.round(item.price * 950),
          stock: item.stock || 0,
          imgUrl: item.thumbnail || (item.images && item.images[0]) || '',
          source: 'importado'
        };
      });

      agregarProductosImportados(productosImportados);
      
      // Solo renderizar si estamos en la página de productos
      if (productosGrid) {
        renderizarProductos(productos);
      }
      
      return;
    }

    throw new Error('No se encontraron productos');
  } catch (error) {
    console.error('Error cargando productos:', error);
    if (productosGrid) {
      mostrarErrorCargaProductos('No se pudieron cargar los productos. Recarga la página para volver a intentar.');
    }
  } finally {
    if (productosGrid) {
      ocultarSpinnerProductos();
    }
  }
}

/**
 * Crear elemento HTML de card de producto
 * @param {Object} producto - Datos del producto
 * @returns {HTMLElement} Card del producto
 */
function crearCardProducto(producto) {
  // Crear contenedor principal
  const card = document.createElement('div');
  card.className = (producto.source === 'externo' || producto.source === 'importado') ? 'producto-card source-externo' : 'producto-card';
  card.setAttribute('data-id', producto.id);
  card.setAttribute('data-categoria', producto.categoria);
  card.setAttribute('data-precio', producto.precio);
  card.setAttribute('data-talla', producto.talla);

  // Definir emojis por categoría
  const emojisCategoria = {
    'basicos': '👕',
    'casual': '👖',
    'formal': '🎩'
  };

  const emoji = emojisCategoria[producto.categoria] || '👗';
  const genero = producto.genero || 'unisex';
  const tallas = producto.sizes && producto.sizes.length ? producto.sizes : [producto.talla || 'Única'];

  // Crear imagen o placeholder si no hay URL
  const imgDiv = document.createElement('div');
  imgDiv.className = 'producto-img';
  if (producto.imgUrl) {
    const img = document.createElement('img');
    img.src = producto.imgUrl;
    img.alt = producto.nombre;
    img.loading = 'lazy';
    img.className = 'producto-thumb';
    imgDiv.appendChild(img);
  } else {
    imgDiv.textContent = emoji;
  }

  // Crear info del producto
  const info = document.createElement('div');
  info.className = 'producto-info';

  // Nombre
  const nombre = document.createElement('div');
  nombre.className = 'producto-nombre';
  nombre.textContent = producto.nombre;

  // Categoría
  const categoria = document.createElement('div');
  categoria.className = 'producto-categoria';
  categoria.textContent = producto.categoria.charAt(0).toUpperCase() + producto.categoria.slice(1);

  // Genero
  const generoInfo = document.createElement('div');
  generoInfo.className = 'producto-genero';
  generoInfo.textContent = `Género: ${genero.charAt(0).toUpperCase() + genero.slice(1)}`;

  // Selector de talla
  const selectorTalla = document.createElement('select');
  selectorTalla.className = 'producto-size-selector';
  tallas.forEach(t => {
    const option = document.createElement('option');
    option.value = t;
    option.textContent = t;
    selectorTalla.appendChild(option);
  });

  // Precio
  const precio = document.createElement('div');
  precio.className = 'producto-precio';
  precio.textContent = `$${producto.precio.toLocaleString()}`;

  // Tallas disponibles
  const tallasList = document.createElement('div');
  tallasList.className = 'producto-tallas-list';
  tallasList.textContent = `Tallas disponibles: ${tallas.join(', ')}`;

  // Stock
  const stock = document.createElement('div');
  stock.className = `producto-stock ${producto.stock > 0 ? 'en-stock' : 'sin-stock'}`;
  stock.textContent = producto.stock > 0 ? `📦 En stock (${producto.stock})` : '❌ Sin stock';

  // Botón agregar al carrito
  const btnAgregar = document.createElement('button');
  btnAgregar.className = 'btn-add-cart';
  btnAgregar.textContent = 'Agregar al Carrito';
  btnAgregar.disabled = producto.stock === 0;
  
  btnAgregar.addEventListener('click', function() {
    agregarAlCarrito(producto.id, 1, selectorTalla.value);
  });

  // Ensamblar elementos
  info.appendChild(nombre);
  info.appendChild(categoria);
  info.appendChild(generoInfo);
  info.appendChild(selectorTalla);
  info.appendChild(tallasList);
  info.appendChild(precio);
  info.appendChild(stock);
  info.appendChild(btnAgregar);

  card.setAttribute('data-genero', genero);
  card.setAttribute('data-tallas', tallas.join(','));
  card.setAttribute('data-talla', tallas[0]);

  card.appendChild(imgDiv);
  card.appendChild(info);

  return card;
}

/**
 * Filtrar productos por categoría
 * @param {String} categoria - Categoría a filtrar
 */
function filtrarPorCategoria(categoria) {
  const cards = document.querySelectorAll('.producto-card');
  
  cards.forEach(card => {
    if (categoria === '' || card.getAttribute('data-categoria') === categoria) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

/**
 * Filtrar productos por rango de precio
 * @param {Number} precioMax - Precio máximo
 */
function filtrarPorPrecio(precioMax) {
  const cards = document.querySelectorAll('.producto-card');
  
  cards.forEach(card => {
    const precio = parseInt(card.getAttribute('data-precio'));
    if (precio <= precioMax) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

/**
 * Buscar productos por nombre
 * @param {String} termino - Término de búsqueda
 */
function buscarProductos(termino) {
  const cards = document.querySelectorAll('.producto-card');
  const terminoNormalizado = normalizarTexto(termino);

  // Si el término está vacío, mostrar todos
  if (termino.trim() === '') {
    cards.forEach(card => card.style.display = 'block');
    return;
  }

  cards.forEach(card => {
    const nombre = normalizarTexto(card.querySelector('.producto-nombre').textContent);
    if (nombre.includes(terminoNormalizado)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

function renderMasVendidos() {
  const grid = document.getElementById('topSellersGrid');
  if (!grid || typeof obtenerTopVendidos !== 'function') return;

  const topVendidos = obtenerTopVendidos(4);
  const contadores = obtenerContadoresVentas();

  if (topVendidos.length === 0) {
    grid.innerHTML = '<p class="top-empty">Aún no hay ventas registradas.</p>';
    return;
  }

  // Filtrar solo productos con ventas
  const productosConVentas = topVendidos.filter(p => contadores[String(p.id)] > 0);
  
  if (productosConVentas.length === 0) {
    grid.innerHTML = '<p class="top-empty">Aún no hay ventas registradas.</p>';
    return;
  }

  grid.innerHTML = '';
  productosConVentas.forEach((producto, index) => {
    const contador = contadores[String(producto.id)] || 0;
    const card = document.createElement('article');
    card.className = 'card-mas-vendido';
    
    const imgUrl = producto.imgUrl || '';
    const imgHtml = imgUrl ? `<div class="card-imagen"><img src="${imgUrl}" alt="${producto.nombre}" class="card-img"></div>` : '';
    
    card.innerHTML = `
      ${imgHtml}
      <div class="card-contenido">
        <h3>${producto.nombre}</h3>
        <p class="top-counter">#${index + 1} más popular • ${contador} venta(s)</p>
        <p>${producto.categoria ? producto.categoria.toUpperCase() : 'Streetwear'} · ${producto.talla || 'Única'}</p>
        <p><strong>$${producto.precio.toLocaleString()}</strong></p>
        <button class="btn-add-cart" type="button">Agregar al Carrito</button>
      </div>
    `;

    card.querySelector('button')?.addEventListener('click', function() {
      agregarAlCarrito(producto.id, 1);
      renderMasVendidos();
    });

    grid.appendChild(card);
  });
}

/**
 * Obtener parámetro de URL
 * @param {String} param - Nombre del parámetro
 * @returns {String|null} Valor del parámetro
 */
function obtenerParametroURL(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
  // Buscar productos
  const searchBtn = document.getElementById('searchBtn');
  const searchInput = document.getElementById('searchInput');

  if (searchBtn && searchInput) {
    searchBtn.addEventListener('click', function() {
      const termino = searchInput.value;
      buscarProductos(termino);
    });

    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        buscarProductos(this.value);
      }
    });
  }

  // Cargar categoría desde URL si existe
  const categoriaURL = obtenerParametroURL('categoria');
  if (categoriaURL) {
    filtrarPorCategoria(categoriaURL);
    // Marcar checkbox si existe
    const checkbox = document.querySelector(`.filtro-categoria[value="${categoriaURL}"]`);
    if (checkbox) {
      checkbox.checked = true;
    }
  }

  const headerSearchInput = document.getElementById('headerSearchInput');
  const headerSearchToggle = document.getElementById('headerSearchToggle');

  if (headerSearchToggle && headerSearchInput) {
    headerSearchToggle.addEventListener('click', function() {
      headerSearchInput.focus();
    });
  }

  if (headerSearchInput) {
    headerSearchInput.addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
        if (typeof buscarConFiltros === 'function') {
          buscarConFiltros(this.value);
        } else {
          buscarProductos(this.value);
        }
      }
    });
  }
});
